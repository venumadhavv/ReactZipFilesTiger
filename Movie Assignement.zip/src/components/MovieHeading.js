import React from 'react'

const MovieHeading = (props) => {
  return (
    <div>
    <h1 style={{color: 'black',marginLeft:"20px"}}>
        {props.MovieHeading}
    </h1>
    </div>
  )
}

export default MovieHeading