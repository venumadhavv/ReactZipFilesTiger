import './App.css';
import ToDoList from './components/ToDoList'
function App() {
 <ToDoList />
}

export default App;
