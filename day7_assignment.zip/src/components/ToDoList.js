import React, { Component } from 'react';
class ToDoList extends Component {

    constructor(props) {
        super(props);
        this.state = {
            value:'',
            todolist: []
        }

        this.showList = this.showList.bind(this);
        this.addToList = this.addToList.bind(this);
        this.handle=this.handle.bind(this);
        this.removeFromList=this.removeFromList.bind(this);
    }
    addToList(e) {
            this.setState({
                value:e.target.value
            });
       

        
    }

    handle(e){
        e.preventDefault();

    }
    showList(){
        if(this.state.value.length>0 )
            this.setState({
                todolist: [...this.state.todolist, this.state.value],
                value: ''
            })
        
        else{
            alert('enter the value in input field')
        }
    }
    removeFromList(){
        if(this.state.todolist.length<1){
            alert("List is Empty");
        }
        
        else{
            this.setState({
                todolist: [...this.state.todolist.slice(0,-1)]
            });
        }
    }
    render(){
        return(
                        <div>
                        <form onSubmit={this.handle}>
                            <h1>TO DO LIST</h1>
                            <input type="text"value={this.state.value} onChange={this.addToList}/>
                            
                            <hr></hr>
                            <input onClick={this.showList} type="submit" value="addToList"/>
                            <input style={{marginLeft:'20px'}} onClick={this.removeFromList} type="submit" value="deleteFromList"/>

                        </form>
                        <div style={{textAlign:"center"}}>

                            <ul style={{listStyle:'none',}}>
                                { this.state.todolist.map((num,i) =>(<li key={i} style={{border:'1px solid red',maxWidth:'20%',backgroundColor:'pink',textAlign:'center '}}>{i}){num}</li>))}
                            </ul>
                        </div>
                    </div>
        );
    }


}

export default ToDoList;
