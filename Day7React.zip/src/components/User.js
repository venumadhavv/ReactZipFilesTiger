function User(props){
    const num=[1,2,3,4,5];
   const  word=['a','b','c','d','e'];
    const item=num.map(
        (number)=><li>{number}</li>
    );
    return(
            <div>
               <ul>
                   {item}

                  
               </ul>
                {/* we can directly write here also */}
               {word.map(
                       (String)=><h1>{String}</h1>
                   )}
            </div>
    );
}
export default User;