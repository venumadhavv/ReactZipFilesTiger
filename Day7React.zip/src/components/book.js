import React,{Component} from "react";

class Book extends Component{
    constructor(props){
        super(props);
        this.state={
            color:"red",
            description:"this is book which tells about the adv of coding",
            bgcolor:"white"
        }
        this.modifycolor=this.modifycolor.bind(this);
        this.changebackground=this.changebackground.bind(this);
    }

    modifycolor(){
        this.setState((state,props)=>({
            color:state.color==="red"?"blue":"red"
        }));
    }
    changebackground(){
        this.setState((state,props)=>({
                bgcolor:"red"
        }));
    }
    render(){
        return(
            <div>
                <h1 style={{color:this.state.color}}>
                    {this.props.title}.The current color is :{this.state.color}
                </h1>
                <h1>Descripton</h1>
                <h2 style={{backgroundColor:this.state.bgcolor}}>{this.state.description}</h2>
                <button onClick={this.modifycolor}>changecolor</button>
                <button onClick={this.changebackground}>changebackground</button>

            </div>
        );
    }
}
export default Book;