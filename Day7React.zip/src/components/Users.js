import React,{Component} from "react";
class Users extends Component{
    constructor(props){
        super(props);
        this.state={
            name:"John",
            userBg:"white",
            city:"Banglore"
        }
        this.modifyCity=this.modifyCity.bind(this);
        console.log("User Constructed");
    }
    componentDidUpdate(){
        console.log("Updated");
    }
    shouldComponentUpdate(){
        console.log(this.state.city);
        if(this.state.city==="Banglore"){
            console.log("component not updated");
            return false;
        }
        else{
            console.log("component updated");
            return true;
        }
    }
    modifyCity(){
        console.log("City modified");
        this.setState({
            city:"Pune",
            userBg:"yellow"
        });
        console.log(this.state.city);
    }

    getSnapshotBeforeUpdate(){
        console.log("snapshot taken");
    }
    render(){
        console.log("User rendered!");
        return(
            <div>
                <p style={
                    {backgroundColor:this.state.userBg}
                }>This is {this.state.name} from {this.state.city}.</p>
                <button onClick={this.modifyCity}>Click</button>
                    
            </div>
        );
    }
    componentDidMount(){
        console.log("User mounted");
    }
}
export default Users;