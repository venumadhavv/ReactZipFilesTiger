function Courses(props){
    return(
        <div>
            <h2> your name is {props.name}</h2>
        </div>
    );
}
export default Courses;