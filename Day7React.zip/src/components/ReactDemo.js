import React,{Component} from "react";

class ReactDemo extends Component{

    constructor(){
        super();
        this.state={
            userloggin:true
        }
    }
    render(){
        // return( this.state.userloggin ?<p> user is logged</p> : <p> user is exitedd</p>
           

        // );
        if(this.setState.userloggin==true){
            return(<p> user is logged</p> );
        }
        else{
            
            return(<p>{this.state.userloggin}</p> );
        }

    }
}
export default ReactDemo;