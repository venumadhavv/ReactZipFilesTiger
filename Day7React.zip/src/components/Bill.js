import React,{Component} from 'react';
class Bill extends Component{
    constructor(props){
        super(props);
        this.state={
            billAmount:100
        }
    }
    render(){
        return(
            <div>
                <p> Total bill is : {this.props.totalBill}</p>
                <p> New bill is : {this.state.billAmount}</p>

            </div>
        );
    }
}
export default Bill;