import logo from './logo.svg';
import './App.css';
import User from './components/User';
import Bill from './components/Bill';
import Courses from './components/Courses';
import Book from './components/book';
function App() {
  return (
    <div className="App">
      <header className="App-header">
      <h1> This is a new heading</h1>
      <User username="john" age="50"/>
      <Bill totalBill="500"/>
      <Courses name="venu"/>
      </header>
      <Book title="venu" />

    </div>
  );
}

export default App;
